from electroncash.i18n import _

fullname = 'wallet-economics'
description = _('This plugin shows you a couple key wallet economics stats.')
available_for = ['qt']
